# Avocado
Say hello to Avocado, a hip, geometric site template.

[eatapapaya.com](https://www.eatapapaya.com)
[@jrdnbwmn](https://www.twitter.com/jrdnbwmn)

Demo images from [Unsplash](https://unsplash.com/).
Icons from [Entypo](http://entypo.com/).

## Instructions
For local development, run `npm install` on the main directory and then `gulp` to get BrowserSync going along with all the Gulp tasks (see [Pear](https://github.com/jrdnbwmn/Pear)).

You can then work on the files in `src` and everything will be compiled into `dist`.